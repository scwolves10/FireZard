// migrations/deploy_1.js

const { deployProxy } = require('@openzeppelin/truffle-upgrades');

const FZ_Dragon = artifacts.require('FZ_Dragon');
const FireZard = artifacts.require('FireZard');


module.exports = async function (deployer) {
  await deployProxy(FZ_Dragon, { deployer, initializer: 'FZ_initialize' });
  await deployProxy(FireZard, { deployer, initializer: 'FZinitialize' });
}